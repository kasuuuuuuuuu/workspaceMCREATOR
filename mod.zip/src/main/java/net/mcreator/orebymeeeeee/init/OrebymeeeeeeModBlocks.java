
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.orebymeeeeee.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

import net.mcreator.orebymeeeeee.block.BlockbcBlock;
import net.mcreator.orebymeeeeee.block.BcdimensionPortalBlock;
import net.mcreator.orebymeeeeee.block.BRmineraisBlock;
import net.mcreator.orebymeeeeee.OrebymeeeeeeMod;

public class OrebymeeeeeeModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, OrebymeeeeeeMod.MODID);
	public static final RegistryObject<Block> B_RMINERAIS = REGISTRY.register("b_rminerais", () -> new BRmineraisBlock());
	public static final RegistryObject<Block> BLOCKBC = REGISTRY.register("blockbc", () -> new BlockbcBlock());
	public static final RegistryObject<Block> BCDIMENSION_PORTAL = REGISTRY.register("bcdimension_portal", () -> new BcdimensionPortalBlock());
}

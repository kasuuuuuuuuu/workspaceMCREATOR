
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.orebymeeeeee.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.biome.Biome;

import net.mcreator.orebymeeeeee.world.biome.BcbiomeBiome;
import net.mcreator.orebymeeeeee.OrebymeeeeeeMod;

public class OrebymeeeeeeModBiomes {
	public static final DeferredRegister<Biome> REGISTRY = DeferredRegister.create(ForgeRegistries.BIOMES, OrebymeeeeeeMod.MODID);
	public static final RegistryObject<Biome> BCBIOME = REGISTRY.register("bcbiome", () -> BcbiomeBiome.createBiome());
}

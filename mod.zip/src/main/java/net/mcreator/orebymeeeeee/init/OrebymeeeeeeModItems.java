
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.orebymeeeeee.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.BlockItem;

import net.mcreator.orebymeeeeee.item.PickaxebcItem;
import net.mcreator.orebymeeeeee.item.JkftruItem;
import net.mcreator.orebymeeeeee.item.HammerbcItem;
import net.mcreator.orebymeeeeee.item.BcdimensionItem;
import net.mcreator.orebymeeeeee.item.BCINGOTItem;
import net.mcreator.orebymeeeeee.item.BCArmorItem;
import net.mcreator.orebymeeeeee.OrebymeeeeeeMod;

public class OrebymeeeeeeModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, OrebymeeeeeeMod.MODID);
	public static final RegistryObject<Item> BC_ARMOR_HELMET = REGISTRY.register("bc_armor_helmet", () -> new BCArmorItem.Helmet());
	public static final RegistryObject<Item> BC_ARMOR_CHESTPLATE = REGISTRY.register("bc_armor_chestplate", () -> new BCArmorItem.Chestplate());
	public static final RegistryObject<Item> BC_ARMOR_LEGGINGS = REGISTRY.register("bc_armor_leggings", () -> new BCArmorItem.Leggings());
	public static final RegistryObject<Item> BC_ARMOR_BOOTS = REGISTRY.register("bc_armor_boots", () -> new BCArmorItem.Boots());
	public static final RegistryObject<Item> B_RMINERAIS = block(OrebymeeeeeeModBlocks.B_RMINERAIS, CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final RegistryObject<Item> BCINGOT = REGISTRY.register("bcingot", () -> new BCINGOTItem());
	public static final RegistryObject<Item> PICKAXEBC = REGISTRY.register("pickaxebc", () -> new PickaxebcItem());
	public static final RegistryObject<Item> BLOCKBC = block(OrebymeeeeeeModBlocks.BLOCKBC, CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final RegistryObject<Item> HAMMERBC = REGISTRY.register("hammerbc", () -> new HammerbcItem());
	public static final RegistryObject<Item> BCDIMENSION = REGISTRY.register("bcdimension", () -> new BcdimensionItem());
	public static final RegistryObject<Item> JKFTRU = REGISTRY.register("jkftru", () -> new JkftruItem());

	private static RegistryObject<Item> block(RegistryObject<Block> block, CreativeModeTab tab) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties().tab(tab)));
	}
}
